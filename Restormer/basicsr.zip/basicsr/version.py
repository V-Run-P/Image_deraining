# GENERATED VERSION FILE
# TIME: Sat Apr 22 20:02:13 2023
__version__ = '1.2.0+733ceb2'
short_version = '1.2.0'
version_info = (1, 2, 0)
